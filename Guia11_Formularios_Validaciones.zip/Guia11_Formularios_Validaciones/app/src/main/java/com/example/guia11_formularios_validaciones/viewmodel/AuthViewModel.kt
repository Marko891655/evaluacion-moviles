package com.example.guia11_formularios_validaciones.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LoginUiState(
    val username: String = "",
    val password: String = "",
    val usernameError: String? = null,
    val passwordError: String? = null,
    val isLoading: Boolean = false,
    val isLoginSuccessful: Boolean = false
)

class AuthViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onUsernameChanged(username: String) {
        _uiState.update { it.copy(username = username, usernameError = null) }
    }

    fun onPasswordChanged(password: String) {
        _uiState.update { it.copy(password = password, passwordError = null) }
    }

    fun login(onSuccess: () -> Unit) {
        val current = _uiState.value
        var hasError = false

        if (current.username.isBlank()) {
            _uiState.update { it.copy(usernameError = "El usuario es requerido") }
            hasError = true
        }
        if (current.password.isBlank()) {
            _uiState.update { it.copy(passwordError = "La contraseña es requerida") }
            hasError = true
        }

        if (hasError) return

        if (current.username == "admin" && current.password == "admin123") {
            onSuccess()
        } else {
            _uiState.update { 
                it.copy(
                    usernameError = "Credenciales incorrectas",
                    passwordError = "Credenciales incorrectas"
                )
            }
        }
    }
}
