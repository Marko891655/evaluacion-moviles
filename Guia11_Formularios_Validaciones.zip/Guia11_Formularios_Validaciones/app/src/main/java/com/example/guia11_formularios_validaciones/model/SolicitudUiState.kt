package com.example.guia11_formularios_validaciones.model

data class SolicitudUiState(
    val titulo: String = "",
    val descripcion: String = "",
    val categoria: String = "Soporte Técnico",
    val servicio: String = "",
    val evidenciaUri: String? = null,

    val tituloError: String? = null,
    val descripcionError: String? = null,
    val categoriaError: String? = null,
    val servicioError: String? = null,

    val guardando: Boolean = false,
    val guardadoExitosamente: Boolean = false
)
