package com.example.guia11_formularios_validaciones.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
