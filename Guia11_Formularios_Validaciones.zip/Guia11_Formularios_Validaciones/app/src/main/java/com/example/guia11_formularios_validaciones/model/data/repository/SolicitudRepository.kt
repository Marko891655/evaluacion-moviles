package com.example.guia11_formularios_validaciones.model.data.repository

import com.example.guia11_formularios_validaciones.model.data.local.SolicitudDao
import com.example.guia11_formularios_validaciones.model.data.local.SolicitudEntity
import kotlinx.coroutines.flow.Flow

class SolicitudRepository(private val solicitudDao: SolicitudDao) {
    val listaSolicitudes: Flow<List<SolicitudEntity>> = solicitudDao.obtenerSolicitudes()

    suspend fun insertar(solicitud: SolicitudEntity) {
        solicitudDao.insertarSolicitud(solicitud)
    }

    suspend fun obtenerPorId(id: Long): SolicitudEntity? {
        return solicitudDao.obtenerSolicitudPorId(id)
    }

    suspend fun obtenerPorCodigo(codigo: String): SolicitudEntity? {
        return solicitudDao.obtenerSolicitudPorCodigo(codigo)
    }

    suspend fun actualizar(solicitud: SolicitudEntity) {
        solicitudDao.actualizarSolicitud(solicitud)
    }

    suspend fun eliminar(solicitud: SolicitudEntity) {
        solicitudDao.eliminarSolicitud(solicitud)
    }
}
